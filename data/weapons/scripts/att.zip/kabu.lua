 local combat1 = createCombatObject()
 
setCombatParam(combat1, COMBAT_PARAM_TYPE, COMBAT_PHYSICALDAMAGE)
function onGetFormulaValues(cid, level, maglevel)
skill = getPlayerSkill(cid,1)
min = -((skill*100)+level)
max = -((skill*130)+level)
return min, max
end
 
setCombatCallback(combat1, CALLBACK_PARAM_LEVELMAGICVALUE, "onGetFormulaValues")
 
local combat2 = createCombatObject()
setCombatParam(combat2, COMBAT_PARAM_EFFECT, 234)
setCombatParam(combat2, COMBAT_PARAM_TYPE, COMBAT_PHYSICALDAMAGE)
function onGetFormulaValues(cid, level, maglevel)
skill = getPlayerSkill(cid,1)
min = -((skill*100+level)
max = -((skill*130)+level)
return min, max
end
 
setCombatCallback(combat2, CALLBACK_PARAM_LEVELMAGICVALUE, "onGetFormulaValues")
 
local combat3 = createCombatObject()
setCombatParam(combat3, COMBAT_PARAM_EFFECT, 234)
setCombatParam(combat3, COMBAT_PARAM_TYPE, COMBAT_PHYSICALDAMAGE)
function onGetFormulaValues(cid, level, maglevel)
skill = getPlayerSkill(cid,1)
min = -((skill*100)+level)
max = -((skill*130)+level)
return min, max
end
 
setCombatCallback(combat3, CALLBACK_PARAM_LEVELMAGICVALUE, "onGetFormulaValues")
 
function onUseWeapon(cid, var)
Critical = math.random(1,100)
if Critical > 80 then
doSendAnimatedText(getPlayerPosition(cid), "Critical!", TEXTCOLOR_DARKORANGE)
doCombat(cid, combat2, var)
end
 
Critical = math.random(1,100)
if Critical < 2 then
doSendAnimatedText(getPlayerPosition(cid), "Critical!", TEXTCOLOR_DARKORANGE)
doCombat(cid, combat3, var)
else
doCombat(cid, combat1, var)
end
end